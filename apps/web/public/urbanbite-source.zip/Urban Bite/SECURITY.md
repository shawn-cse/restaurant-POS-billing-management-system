# Urban Bite security and deployment notes

Urban Bite is a self-hosted restaurant POS distribution. For a security issue,
contact the operator responsible for your Urban Bite deployment; avoid posting
customer data or credentials publicly. The upstream copyright and license
information is in `NOTICE` and `COPYRIGHT`.

- Keep the generated `.env` private; it includes the PostgreSQL password and
  JWT signing key. Never place it in a public source repository.
- Protect access to the Docker host and give staff only the permissions they need.
- Use an HTTPS reverse proxy for internet-facing instances. Set
  `FRONTEND_ORIGIN`, `PUBLIC_BASE_URL`, `TRUST_PROXY`, and `COOKIE_SECURE=true`.
- Create periodic protected off-site database/attachment backups and test restores.
- Configure payment gateway credentials only in Settings or private deployment
  secrets, then test authorization, refunds, webhooks and reconciliation.
- Validate application and dependency updates locally. The upstream automatic
  updater was removed to prevent this distribution being overwritten by a
  different upstream software image.
- Direct USB printing is an opt-in Linux-only Compose override. Test actual
  printers and cash drawers in the restaurant.

The project has not been subject to a security audit after rebranding.
Do not treat the provided code as payment-card security certification.
