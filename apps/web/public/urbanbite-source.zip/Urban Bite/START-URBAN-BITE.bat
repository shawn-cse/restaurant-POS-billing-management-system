@echo off
cd /d "%~dp0"
where docker >nul 2>nul
if errorlevel 1 (
  echo Please install and start Docker Desktop first.
  pause
  exit /b 1
)
docker compose up -d --build
if errorlevel 1 (
  echo Startup failed. Check Docker Desktop and the console output.
  pause
  exit /b 1
)
echo Urban Bite address: http://localhost:1995
pause
