import {
  ForbiddenException,
  Injectable,
  NotFoundException,
  UnprocessableEntityException,
} from '@nestjs/common';
import { createHash } from 'node:crypto';
import { Prisma } from '@prisma/client';
import type {
  CreateIntegrationOrderDto,
  CreateIntegrationReservationDto,
  IntegrationRewardsLookupDto,
} from '@urbanbite/types';
import { adjustOnlinePrice, onlinePriceAdjustOf } from '../common/online-price';
import { PrismaService } from '../prisma/prisma.service';
import { DeliveryService } from '../modules/delivery/delivery.service';
import { OrdersService } from '../modules/orders/orders.service';
import { ReferralsService } from '../modules/referrals/referrals.service';
import { ReservationsService } from '../modules/reservations/reservations.service';

/** Extra scope that unlocks customer contact and delivery address on reads. */
export const PERSONAL_DATA_SCOPE = 'orders:read_customer';

const OWN_ORDER_INCLUDE = {
  items: { include: { modifiers: true }, orderBy: { id: 'asc' } },
  customer: { select: { name: true, phone: true, email: true } },
  kots: { select: { status: true } },
  payments: { select: { amount: true } },
} satisfies Prisma.OrderInclude;

type OwnOrder = Prisma.OrderGetPayload<{ include: typeof OWN_ORDER_INCLUDE }>;

export interface IntegrationKeyContext {
  id: string;
  restaurantId: string;
  branchId: string | null;
  scopes: string[];
}

/**
 * Backs the public REST API external websites use as a backend (see
 * docs/integrations-api.md). Every method takes the caller's
 * IntegrationKeyContext and re-validates the requested branch belongs to
 * that key's restaurant AND (if the key itself is scoped to one location)
 * matches exactly — never trusts a client-supplied branchId on its own,
 * same discipline OrdersService/ReservationsService already apply to
 * staff-supplied tableId/customerId.
 */
@Injectable()
export class IntegrationsService {
  constructor(
    private readonly prisma: PrismaService,
    private readonly orders: OrdersService,
    private readonly delivery: DeliveryService,
    private readonly reservations: ReservationsService,
    private readonly referrals: ReferralsService,
  ) {}

  private async assertBranch(ctx: IntegrationKeyContext, branchId: string) {
    if (ctx.branchId && ctx.branchId !== branchId) {
      throw new ForbiddenException(
        'This API key is scoped to a different location',
      );
    }
    const branch = await this.prisma.branch.findFirst({
      where: { id: branchId, restaurantId: ctx.restaurantId, isActive: true },
    });
    if (!branch) {
      throw new NotFoundException('Location not found');
    }
    return branch;
  }

  async listLocations(ctx: IntegrationKeyContext) {
    return this.prisma.branch.findMany({
      where: {
        restaurantId: ctx.restaurantId,
        isActive: true,
        ...(ctx.branchId ? { id: ctx.branchId } : {}),
      },
      select: { id: true, name: true, address: true, phone: true },
      orderBy: { name: 'asc' },
    });
  }

  async getMenu(ctx: IntegrationKeyContext, branchId: string) {
    const branch = await this.assertBranch(ctx, branchId);
    const categories = await this.prisma.menuCategory.findMany({
      where: { branchId: branch.id, isActive: true, showOnWebsite: true },
      orderBy: { sortOrder: 'asc' },
      include: {
        items: {
          where: { isActive: true },
          orderBy: { sortOrder: 'asc' },
          select: {
            id: true,
            name: true,
            description: true,
            imageUrl: true,
            price: true,
            taxRatePercent: true,
            isVeg: true,
            isVegan: true,
            spiceLevel: true,
            allergens: true,
            // "HH:mm" window the item can be ordered in, if the owner set one.
            availableFrom: true,
            availableTo: true,
            modifierGroups: {
              orderBy: { sortOrder: 'asc' },
              select: {
                modifierGroup: {
                  select: {
                    id: true,
                    name: true,
                    minSelect: true,
                    maxSelect: true,
                    isRequired: true,
                    modifiers: {
                      where: { isActive: true },
                      orderBy: { sortOrder: 'asc' },
                      select: {
                        id: true,
                        name: true,
                        priceAdjustment: true,
                        isDefault: true,
                      },
                    },
                  },
                },
              },
            },
          },
        },
      },
    });
    const adjust = onlinePriceAdjustOf(
      await this.prisma.restaurant.findUniqueOrThrow({
        where: { id: ctx.restaurantId },
        select: { onlinePriceAdjustKind: true, onlinePriceAdjustValue: true },
      }),
    );
    return {
      locationId: branch.id,
      locationName: branch.name,
      categories: categories.map((category) => ({
        ...category,
        items: category.items.map(({ modifierGroups, ...item }) => ({
          ...item,
          // The price a website customer pays: the Settings price change is already applied.
          price:
            adjust && item.price != null
              ? adjustOnlinePrice(Number(item.price), adjust)
              : item.price,
          modifierGroups: modifierGroups.map((g) => g.modifierGroup),
        })),
      })),
    };
  }

  async createOrder(
    ctx: IntegrationKeyContext,
    branchId: string,
    dto: CreateIntegrationOrderDto,
    idempotencyKey?: string,
  ) {
    await this.assertBranch(ctx, branchId);

    // Scoped to the key so two websites can never collide on (or probe) each
    // other's idempotency keys.
    const clientRequestId = idempotencyKey
      ? `int:${ctx.id}:${idempotencyKey}`
      : undefined;
    // The same key must mean the same request: a different body under a used
    // key is a client bug, so say so instead of silently returning another order.
    const clientRequestHash = createHash('sha256')
      .update(JSON.stringify(dto))
      .digest('hex');
    const replayOf = (order: OwnOrder) => {
      if (order.clientRequestHash !== clientRequestHash) {
        throw new UnprocessableEntityException(
          'This Idempotency-Key was already used with a different request',
        );
      }
      return this.present(ctx, order);
    };
    if (clientRequestId) {
      const replay = await this.findOwnOrder(ctx, branchId, {
        clientRequestId,
      });
      if (replay) return replayOf(replay);
    }

    // find-or-attach a lightweight Customer record so repeat integration
    // orders from the same phone number accumulate under one profile.
    const customer = await this.customerFor(
      branchId,
      dto.customerName,
      dto.customerPhone,
      dto.customerEmail,
    );

    // An external order has no staff member behind it, but Order.createdById
    // is a required FK — attribute it to any staff linked to the branch
    // (every branch has at least its owner), same fallback the QR
    // self-order flow already uses for the identical reason.
    const createdById = (
      await this.prisma.userBranch.findFirst({
        where: { branchId },
        orderBy: { userId: 'asc' },
      })
    )?.userId;
    if (!createdById) {
      throw new NotFoundException(
        'This location has no staff to receive the order',
      );
    }

    // Prices, tax and the delivery fee are all worked out by OrdersService
    // from the live menu and the location's zones; nothing monetary from the
    // caller is read (the schema strips unknown fields).
    const settings = await this.prisma.restaurant.findUniqueOrThrow({
      where: { id: ctx.restaurantId },
      select: {
        onlineMinOrderAmount: true,
        onlinePriceAdjustKind: true,
        onlinePriceAdjustValue: true,
      },
    });
    const minOrderAmount = Number(settings.onlineMinOrderAmount);
    const priceAdjust = onlinePriceAdjustOf(settings);
    for (let attempt = 1; ; attempt++) {
      try {
        const created = await this.orders.createOrder(
          branchId,
          createdById,
          {
            type: dto.type,
            customerId: customer.id,
            guestName: dto.customerName,
            notes: dto.notes,
            // A delivery order always carries its contact details, even for
            // a location that has no delivery zones configured.
            delivery: dto.delivery && {
              address: dto.delivery.address,
              pincode: dto.delivery.pincode,
              phone: dto.delivery.phone ?? dto.customerPhone,
              lat: dto.delivery.lat,
              lng: dto.delivery.lng,
              place: dto.delivery.place,
            },
            scheduledFor: dto.scheduledFor,
            items: dto.items.map((item) => ({
              menuItemId: item.menuItemId,
              quantity: item.quantity,
              modifierIds: item.modifierIds,
              kitchenNote: item.kitchenNote,
            })),
          },
          {
            channel: 'ONLINE',
            requireAcceptance: true,
            clientRequestId,
            clientRequestHash,
            integrationKeyId: ctx.id,
            minOrderAmount: minOrderAmount > 0 ? minOrderAmount : undefined,
            priceAdjust,
          },
        );
        const rewards =
          dto.referralCode || dto.redeemPoints
            ? await this.applyRewards(
                ctx,
                branchId,
                created.id,
                customer.id,
                dto,
              )
            : undefined;
        const order = await this.findOwnOrder(ctx, branchId, {
          id: created.id,
        });
        return {
          ...this.present(ctx, order!),
          ...(rewards ? { rewards } : {}),
        };
      } catch (err) {
        if (
          err instanceof Prisma.PrismaClientKnownRequestError &&
          err.code === 'P2002'
        ) {
          // A concurrent retry with the same Idempotency-Key won the race...
          if (clientRequestId) {
            const dup = await this.findOwnOrder(ctx, branchId, {
              clientRequestId,
            });
            if (dup) return replayOf(dup);
          }
          // ...or two orders raced for the same daily order number.
          if (attempt < 3) continue;
        }
        throw err;
      }
    }
  }

  private async customerFor(
    branchId: string,
    name: string,
    phone: string,
    email?: string,
  ) {
    const existing = await this.prisma.customer.findFirst({
      where: { branchId, phone },
    });
    return existing
      ? this.prisma.customer.update({
          where: { id: existing.id },
          data: {
            name: name || existing.name,
            ...(email && !existing.email ? { email } : {}),
          },
        })
      : this.prisma.customer.create({
          data: { branchId, name, phone, email },
        });
  }

  /**
   * Referral attribution and a points-redemption request for a freshly placed
   * order. Neither can fail the order: a bad code or an empty balance is
   * reported back instead. Attribution is idempotent (one referral per
   * customer) and no points are paid until the first purchase is paid.
   */
  private async applyRewards(
    ctx: IntegrationKeyContext,
    branchId: string,
    orderId: string,
    customerId: string,
    dto: CreateIntegrationOrderDto,
  ) {
    const out: {
      referral?: { applied: boolean; reason?: string };
      redeem?: { points: number; discount: number };
    } = {};
    if (dto.referralCode) {
      try {
        const r = await this.referrals.attach(
          ctx.restaurantId,
          customerId,
          dto.referralCode,
          dto.sharedItemId,
        );
        out.referral = r.applied
          ? { applied: true }
          : { applied: false, reason: r.reason };
      } catch {
        out.referral = {
          applied: false,
          reason: 'Referral could not be recorded',
        };
      }
    }
    if (dto.redeemPoints) {
      const [cust, rest, order] = await Promise.all([
        this.prisma.customer.findUniqueOrThrow({
          where: { id: customerId },
          select: { loyaltyPoints: true },
        }),
        this.prisma.restaurant.findUniqueOrThrow({
          where: { id: ctx.restaurantId },
          select: { loyaltyPointValue: true },
        }),
        this.prisma.order.findUniqueOrThrow({
          where: { id: orderId },
          select: { subtotal: true },
        }),
      ]);
      const value = Number(rest.loyaltyPointValue);
      if (value > 0) {
        // Never more than the balance, never more than the bill is worth.
        const cap = Math.floor(Number(order.subtotal) / value);
        const points = Math.max(
          0,
          Math.min(dto.redeemPoints, cust.loyaltyPoints, cap),
        );
        if (points > 0) {
          await this.prisma.order.update({
            where: { id: orderId },
            data: { requestedRedeemPoints: points },
          });
          out.redeem = {
            points,
            discount: Math.round(points * value * 100) / 100,
          };
        }
      }
    }
    return out;
  }

  /** Balance, rewards and referral link data for a website customer. */
  async rewards(
    ctx: IntegrationKeyContext,
    branchId: string,
    dto: IntegrationRewardsLookupDto,
  ) {
    await this.assertBranch(ctx, branchId);
    const customer = await this.customerFor(
      branchId,
      dto.customerName ?? '',
      dto.customerPhone,
    );
    return this.referrals.summary(ctx.restaurantId, customer.id);
  }

  /** Fee / minimum / ETA for a pincode, so a website can quote before ordering. */
  async deliveryQuote(
    ctx: IntegrationKeyContext,
    branchId: string,
    pincode: string,
  ) {
    await this.assertBranch(ctx, branchId);
    return this.delivery.quote(branchId, pincode);
  }

  /**
   * An order this key placed, with its status, items and totals. Customer and
   * delivery details are only included when `includeCustomer` is requested,
   * which needs the separate `orders:read_customer` scope.
   */
  async getOrder(
    ctx: IntegrationKeyContext,
    branchId: string,
    orderId: string,
    includeCustomer = false,
  ) {
    if (includeCustomer && !ctx.scopes.includes(PERSONAL_DATA_SCOPE)) {
      throw new ForbiddenException(
        `Reading customer details needs the ${PERSONAL_DATA_SCOPE} scope`,
      );
    }
    await this.assertBranch(ctx, branchId);
    const order = await this.findOwnOrder(ctx, branchId, { id: orderId });
    // Same 404 whether the order doesn't exist or belongs to someone else.
    if (!order) throw new NotFoundException('Order not found');
    return this.present(ctx, order, includeCustomer);
  }

  private findOwnOrder(
    ctx: IntegrationKeyContext,
    branchId: string,
    where: { id: string } | { clientRequestId: string },
  ) {
    return this.prisma.order.findFirst({
      where: { ...where, branchId, integrationKeyId: ctx.id },
      include: OWN_ORDER_INCLUDE,
    });
  }

  /**
   * Explicit allow-list of what leaves the API. Deliberately not the raw
   * Prisma row: that carries loyalty/wallet balances, allergy notes, staff
   * ids, table and driver references that a website has no business seeing.
   */
  private present(
    ctx: IntegrationKeyContext,
    order: OwnOrder,
    includeCustomer = false,
  ) {
    const num = (v: Prisma.Decimal | null) => (v ? Number(v) : 0);
    const subtotal = num(order.subtotal);
    const discount =
      num(order.discountAmount) + num(order.loyaltyDiscountAmount);
    const deliveryFee = num(order.deliveryFee);
    const wantsCustomer =
      includeCustomer && ctx.scopes.includes(PERSONAL_DATA_SCOPE);
    return {
      id: order.id,
      orderNumber: order.orderNumber,
      type: order.type,
      status: order.status,
      // PENDING until staff accept an online order (unless auto-confirm is on).
      acceptance: order.acceptance,
      kitchenStatus: order.kots.length ? order.kots.map((k) => k.status) : [],
      createdAt: order.createdAt,
      scheduledFor: order.scheduledFor,
      notes: order.notes,
      items: order.items.map((item) => ({
        name: item.nameSnapshot,
        quantity: item.quantity,
        unitPrice: Number(item.unitPriceSnapshot),
        lineTotal: Number(item.lineTotal),
        kitchenNote: item.kitchenNote,
        modifiers: item.modifiers.map((m) => ({
          name: m.nameSnapshot,
          priceAdjustment: Number(m.priceAdjSnapshot),
        })),
      })),
      totals: {
        subtotal,
        tax: num(order.taxAmount),
        discount,
        deliveryFee,
        total: Math.round((subtotal - discount + deliveryFee) * 100) / 100,
        paid: order.payments.reduce((sum, p) => sum + Number(p.amount), 0),
      },
      fulfillment:
        order.type === 'DELIVERY'
          ? {
              deliveryStatus: order.deliveryStatus,
              etaAt: order.deliveryEtaAt,
              deliveredAt: order.deliveredAt,
            }
          : null,
      ...(wantsCustomer
        ? {
            customer: {
              name: order.guestName ?? order.customer?.name ?? null,
              phone: order.customer?.phone ?? null,
              email: order.customer?.email ?? null,
            },
            delivery:
              order.type === 'DELIVERY'
                ? {
                    address: order.deliveryAddress,
                    pincode: order.deliveryPincode,
                    phone: order.deliveryPhone,
                    lat: order.deliveryLat,
                    lng: order.deliveryLng,
                    place: order.deliveryPlace,
                  }
                : null,
          }
        : {}),
    };
  }

  async createReservation(
    ctx: IntegrationKeyContext,
    branchId: string,
    dto: CreateIntegrationReservationDto,
  ) {
    await this.assertBranch(ctx, branchId);
    return this.reservations.create(branchId, dto, { fromWebsite: true });
  }

  async getReservation(
    ctx: IntegrationKeyContext,
    branchId: string,
    reservationId: string,
  ) {
    await this.assertBranch(ctx, branchId);
    // A website key may look up a booking's status, as its scope says. Only online bookings, and only what a
    // status page needs: walk-in and staff-made bookings, and contact details, deposits and table assignments of
    // any booking, are not a website key's to read.
    const reservation = await this.prisma.reservation.findFirst({
      where: { id: reservationId, branchId, channel: 'ONLINE' },
      select: {
        id: true,
        status: true,
        reservedAt: true,
        durationMinutes: true,
        guestCount: true,
        customerName: true,
        createdAt: true,
      },
    });
    if (!reservation) throw new NotFoundException('Reservation not found');
    return reservation;
  }
}
