# Urban Bite — Restaurant Web POS

Urban Bite is a rebranded, **web-only**, self-hosted restaurant point-of-sale and management system.
It includes a Next.js dashboard, a NestJS API, PostgreSQL and the shared Typescript library.

## Quick start (Docker Desktop / Docker Engine + Compose)

1. Install **Docker Desktop** (Windows/macOS) or **Docker Engine + Compose plugin** (Linux).
2. Extract this ZIP, and open a terminal **inside the `Urban Bite` folder**.
3. Run: `docker compose up -d --build` (or run `START-URBAN-BITE.bat` on Windows / `./start-urban-bite.sh` on macOS or Linux).
4. After startup, open **http://localhost:1995** on the device running Docker.
5. Click **Set up Urban Bite** and create your owner account. Your restaurant name is prefilled as **Urban Bite**. Configure taxes, currency, menu and staff in Settings.

The package contains a unique `.env` file with strong random local credentials. **Keep it private** and don't upload it to GitHub. If you lose `.env`, restore it from your personal backup; changing its database password without migrating PostgreSQL credentials will break existing installs.

### Access from another device on your restaurant Wi-Fi

Find the server PC's local IP (example `192.168.1.20`), then browse to `http://192.168.1.20:1995` on your other devices. Set `FRONTEND_ORIGIN=http://192.168.1.20:1995` in `.env` before starting containers, then run `docker compose up -d`. Allow port **1995** through the host firewall. Use a stable host IP. For a public website, configure HTTPS first and set `COOKIE_SECURE=true`.

### Basic maintenance

- `docker compose ps` — check status
- `docker compose logs -f backend web` — inspect startup or application errors
- `docker compose down` — stop containers **without deleting stored data**
- `docker compose up -d --build` — rebuild from your current source after edits
- **Never** run `docker compose down -v` unless you intentionally want to erase the database and uploads.
- The database is **not** prefilled with a demo owner or demo sales: create your real account on first start.

### Printing

Browser print dialogs and network-printer support stay in the project. For USB thermal printers directly attached to a **Linux Docker host**, start with:

`docker compose -f docker-compose.yml -f docker-compose.usb.yml up -d --build`

The optional USB Compose file mounts Linux `/dev/bus/usb`; do not use it on macOS/Windows. Receipt and cash-drawer hardware need on-site testing.

### Architecture

- `apps/web/` — responsive web dashboard, QR ordering, KDS, PWA
- `apps/backend/` — authenticated API, business logic, Prisma schema & migrations
- `packages/types/` — shared API types and validators
- `docker-compose.yml` — PostgreSQL, backend and browser frontend
- `.env` — private local deployment credentials (keep confidential)

This bundle excludes the original native Android/iOS project, desktop installers, promotional site and original software-updater service. Feature support that requires a third-party provider (email, payment gateways, backups, printers, etc.) still needs operator setup and testing.

## Licensing & provenance

This is a **modified distribution** dated **2026-11-16** under **AGPL-3.0-only**. See `LICENSE`, `NOTICE`, `COPYRIGHT` and `TRADEMARK_POLICY.md`. The original copyrights and attributions must remain; rebranding does **not** transfer the original code's copyright or turn it into proprietary software. If you let others use this modified application over a network, provide them access to the corresponding modified source code as required by AGPL section 13. The `/source` page includes the archive under `/urbanbite-source.zip`. Regenerate it with `python3 build-source-archive.py` after modifying the application so the published source matches the running version. The software is supplied without warranty.
