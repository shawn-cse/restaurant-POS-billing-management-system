# Urban Bite web-only customization — 2026-11-16

- Replaced customer- and staff-visible product branding with Urban Bite (login, onboarding, dashboard, metadata, PWA, favicon, logo and source page).
- Updated shared TypeScript workspace package identifiers to `@urbanbite/*` and changed local storage, session cookie, and printed backup labels to the Urban Bite namespace.
- Replaced violet UI accents with an evergreen-teal palette and warm coral logo accent in light/dark/kiosk modes.
- Removed native Android/iOS source code, Windows desktop distribution, legacy install/update sidecar and Docker socket mounting, old promotional front page, device-only settings screens and old promotional assets.
- Created a Docker Compose stack with `urbanbite-*` images and unique deployment secrets in `.env`. Optionally enable Linux USB thermal printers with `docker-compose.usb.yml`.
- Created a restaurant-specific welcome page and prefilled the restaurant name on the initial registration form.
- Preserved required original copyright and AGPL license attribution in legal files and the public `/source` page. Included the full modified corresponding source as a public `/urbanbite-source.zip` download (excluding private `.env`).

**Testing limitation:** A full Docker deployment and dependency installation were not possible in the authoring environment; this is a modified *source distribution*, not a proven production install. Validate with `docker compose up -d --build`, test transactions in your environment, and configure tax/currency/gateways before going live.
